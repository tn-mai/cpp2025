#define _CRT_SECURE_NO_WARNINGS
#define NOMINMAX
#include <Windows.h>
#include "sub.h"
#include "Audio.h"
#include <string>
#include <unordered_map>

#include <objidl.h>
#include <gdiplus.h>
using namespace Gdiplus;
#pragma comment (lib,"Gdiplus.lib")

//���C�u�����̒ǉ�
#pragma comment(lib, "winmm.lib")   //timerBeginPeriod, timerEndPeriod
#pragma comment(lib, "msimg32.lib")	//�摜�֘Aײ����
#pragma comment(lib, "dwmapi.lib")	//�_�[�N���[�h�Ή�

namespace /* unnamed */ {

// ��������ϐ�
std::string bgmFilename;
EasyLib::Audio::SoundPtr bgm;
float bgmVolume = 0.8f;

std::unordered_map<std::string, EasyLib::Audio::SoundPtr> se;

Gdiplus::FontFamily* fontFamily;
float fontSize = 32;

} // unnamed namespace

// �����̏�����
bool InitializeAudio()
{
  if (FAILED(CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE))) {
    return false;
  }
  EasyLib::Audio::Engine::Get().Initialize();
  return true;
}

// �����̏I��
void FinalizeAudio()
{
  se.clear();
  EasyLib::Audio::Engine::Get().Destroy();
  CoUninitialize();
}

// �����̍X�V
void UpdateAudio()
{
  EasyLib::Audio::Engine::Get().Update();
}

GdiplusStartupInput gdiSI;
ULONG_PTR gdiToken = 0;

// GDI+�̏�����
void InitializeGDI()
{
  GdiplusStartup(&gdiToken, &gdiSI, NULL);
}

// GDI+�̏I��
void FinalizeGDI()
{
	GdiplusShutdown(gdiToken);
}

// SJIS����������C�h������ɕϊ�
std::wstring ToWString(const char* s)
{
	int wlen = MultiByteToWideChar(CP_ACP, 0, s, -1, nullptr, 0);
	std::wstring tmp;
	tmp.resize(wlen);
	MultiByteToWideChar(CP_ACP, 0, s, -1, tmp.data(), wlen);
	return tmp;
}

// SJIS����������C�h������ɕϊ�
std::wstring ToWString(const std::string& s)
{
	int wlen = MultiByteToWideChar(CP_ACP, 0, s.data(), -1, nullptr, 0);
	std::wstring tmp;
	tmp.resize(wlen);
	MultiByteToWideChar(CP_ACP, 0, s.data(), -1, tmp.data(), wlen);
	return tmp;
}

//�t�H���g�ǂݍ��݊֐�
bool ReadFont(Gdiplus::Font*& font, const char* fontname, int size, [[maybe_unused]] int weight, bool italic)
{
	const std::wstring ws = ToWString(fontname);
	if (ws.empty()) {
		MessageBox(NULL, "�t�H���g�̓Ǎ��ݎ��s", fontname, MB_OK);
		return false;
	}
	font = new Gdiplus::Font(ws.data(), static_cast<REAL>(size), italic ? Gdiplus::FontStyleItalic : Gdiplus::FontStyleRegular);
	if (!font || font->GetLastStatus() != Status::Ok) {
		MessageBox(NULL, "�t�H���g�̓Ǎ��ݎ��s", fontname, MB_OK);
		return false;
	}
	return true;
}

//�摜�ǂݍ��݊֐�
bool ReadBmp(Gdiplus::Bitmap*& bmp, const char* filename)
{
	const std::wstring ws = ToWString(filename);
	if (ws.empty()) {
		MessageBox(NULL, "�摜�t�@�C���̓Ǎ��ݎ��s", filename, MB_OK);
		return false;
	}
	bmp = Bitmap::FromFile(ws.data());
	if (!bmp || bmp->GetLastStatus() != Status::Ok) {
		MessageBox(NULL, "�摜�t�@�C���̓Ǎ��ݎ��s", filename, MB_OK);
		return false;
	}
	return true;
}

// �摜�\���֐�
void DrawImage(Gdiplus::Graphics* g, Gdiplus::Bitmap* bmp, int x, int y)
{
	g->DrawImage(bmp, x, y);
}

// ������\���֐�
void DrawString(Gdiplus::Graphics* g, const char* text, double x, double y)
{
   DrawString(g, text, x, y, (ARGB)Color::White, 1.0f);
}

// ������\���֐�
void DrawString(Gdiplus::Graphics* g, const char* text, double x, double y, int color)
{
   DrawString(g, text, x, y, color, 1.0f);
}

// ������\���֐�
void DrawString(Gdiplus::Graphics* g, const char* text, double x, double y, int color, double scale)
{
	//�����t�H���g�̍쐬
	if (!fontFamily) {
		fontFamily = new Gdiplus::FontFamily(L"MS Gothic");
		if (!fontFamily) {
			return;
		}
	}

	Gdiplus::Pen pen(Gdiplus::Color(10, 10, 10), 4);
	Gdiplus::SolidBrush brush((ARGB)color);
	Gdiplus::GraphicsPath path;
	std::wstring ws = ToWString(text);
	path.AddString(ws.data(), -1, fontFamily, 0, (Gdiplus::REAL)(fontSize * scale),
		Gdiplus::PointF((float)x, (float)y), Gdiplus::StringFormat::GenericDefault());
	g->DrawPath(&pen, &path);
	g->FillPath(&brush, &path);
}

//BGM�Đ��֐�
void PlayBgm(const char* filename)
{
  if (bgmFilename != filename || !bgm || !(bgm->GetState() & EasyLib::Audio::State_Playing)) {
    if (bgm) {
      bgm->Stop();
    }
    bgmFilename = filename;
    const std::wstring ws = ToWString(bgmFilename);
    bgm = EasyLib::Audio::Engine::Get().PrepareMFStream(ws.c_str());
    if (bgm) {
      bgm->Play(EasyLib::Audio::Flag_Loop);
      bgm->SetVolume(bgmVolume);
    }
  }
}

//BGM��~�֐�
void StopBgm()
{
  bgmFilename.clear();
  if (bgm) {
    bgm->Stop();
    bgm.reset();
  }
}

//BGM���ʒ����֐�
void VolumeBgm(double volume)
{
  bgmVolume = static_cast<float>(volume);
  if (bgm) {
    bgm->SetVolume(bgmVolume);
  }
}

//WAV���O�ǂݍ��݊֐�
void PrepareSe(const char* filename)
{
  auto itr = se.find(filename);
  if (itr == se.end()) {
    const std::wstring ws = ToWString(filename);
    EasyLib::Audio::SoundPtr p = EasyLib::Audio::Engine::Get().PrepareMFStream(ws.c_str());
    se.emplace(std::string(filename), p);
  }
}

//WAV�Đ��֐�
void PlaySe(const char* filename, double volume)
{
  EasyLib::Audio::SoundPtr p;
  auto itr = se.find(filename);
  if (itr == se.end()) {
    const std::wstring ws = ToWString(filename);
    p = EasyLib::Audio::Engine::Get().PrepareMFStream(ws.c_str());
    se.emplace(std::string(filename), p);
  } else {
    p = itr->second;
  }

  if (p) {
    p->Play(EasyLib::Audio::Flag_None);
    p->SetVolume(static_cast<float>(volume));
  }
}

void PlaySe(const char* filename) { PlaySe(filename, 0.8); }

